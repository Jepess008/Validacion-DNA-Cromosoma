package com.campuslands.CRUD_DNA.repositories;

import org.springframework.data.repository.CrudRepository;

import com.campuslands.CRUD_DNA.repositories.entities.Persona;

public interface RepositoryPersona extends CrudRepository<Persona,Long>{
    
}
