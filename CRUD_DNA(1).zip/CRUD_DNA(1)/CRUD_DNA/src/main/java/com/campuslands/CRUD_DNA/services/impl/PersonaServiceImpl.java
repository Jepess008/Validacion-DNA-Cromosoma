package com.campuslands.CRUD_DNA.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.transaction.annotation.Transactional;

import com.campuslands.CRUD_DNA.repositories.RepositoryPersona;
import com.campuslands.CRUD_DNA.repositories.entities.Persona;
import com.campuslands.CRUD_DNA.services.PersonaService;

public class PersonaServiceImpl implements PersonaService{

    private RepositoryPersona repositoryPersona;

    @Override
    @Transactional(readOnly = true)
    public List<Persona> findAll() {
       return (List<Persona>) repositoryPersona.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public Persona findById(Long id) {
       return repositoryPersona.findById(id).orElse(null);
    }

    @Transactional
    @Override
    public Persona save(Persona persona) {
        return repositoryPersona.save(persona);
    }

    @Transactional
    @Override
    public void delete(Long id) {
       Optional<Persona> personaOptional= repositoryPersona.findById(id);
       if(personaOptional.isPresent()){
            repositoryPersona.delete(personaOptional.get());
       }
    }

    @Transactional
    @Override
    public Persona actualizar(Long id, Persona perosnaActualizada) {
        Persona personaExistente = repositoryPersona.findById(id).orElse(null);
        if(personaExistente != null){
            personaExistente.setNombre(perosnaActualizada.getNombre());
            personaExistente.setApellido(perosnaActualizada.getApellido());
            personaExistente.setDireccion(perosnaActualizada.getDireccion());
            personaExistente.setEmail(perosnaActualizada.getEmail());
            return repositoryPersona.save(personaExistente);
        }

        return null;
    }

    @Transactional
    @Override
    public String buscarSospechoso(String cromosomaDNA) {
        List<Persona> listPersonas = (List<Persona>) findAll();
        Persona sospechoso = null;
        double mayorCoincidencia = 0;
        double coincidencias;

        if (listPersonas.isEmpty()) {
            return "No hay datos de personas";
        } else {
            for (Persona persona : listPersonas) {
                coincidencias = 0;
                for (int i = 0; i < cromosomaDNA.length(); i++) {
                    if (cromosomaDNA.charAt(i) == persona.getCromosoma().charAt(i)) {
                        coincidencias++;
                    }
                }
                double porcentajeCoincidencia = (coincidencias / cromosomaDNA.length()) * 100;
                if (porcentajeCoincidencia > mayorCoincidencia) {
                    mayorCoincidencia = porcentajeCoincidencia;
                    sospechoso = persona;
                }
            }
        }
        return "Sospechoso: " + sospechoso.getNombre() + " " + sospechoso.getApellido() +
                ", Porcentaje de parentezco: " + mayorCoincidencia + "%";
    }

}
