package com.campuslands.CRUD_DNA.services;

import java.util.List;

import com.campuslands.CRUD_DNA.repositories.entities.Persona;

public interface PersonaService {
    
    List<Persona> findAll();

    Persona findById(Long id);

    Persona save(Persona persona);

    void delete (Long id);

    Persona actualizar(Long id, Persona perosnaActualizada);

    String buscarSospechoso(String cromosomaDNA); 
    
}
