package com.campuslands.CRUD_DNA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudDnaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudDnaApplication.class, args);
	}

}
