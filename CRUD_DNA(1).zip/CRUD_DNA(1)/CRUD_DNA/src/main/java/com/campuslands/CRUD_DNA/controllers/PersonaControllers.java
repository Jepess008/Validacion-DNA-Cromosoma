package com.campuslands.CRUD_DNA.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.campuslands.CRUD_DNA.repositories.entities.Persona;
import com.campuslands.CRUD_DNA.services.PersonaService;

import lombok.AllArgsConstructor;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/persona")
@AllArgsConstructor
public class PersonaControllers {

    private final PersonaService personaService;

    @GetMapping("/")
    public List<Persona> findAll(){
        return personaService.findAll();
    }
    
    @GetMapping("/{id}")
    public Persona findAllByString(@PathVariable Long id) {
        return personaService.findById(id);
    }

    @PostMapping("/")
    public Persona save(@RequestBody Persona persona) {
        return personaService.save(persona);
    }

    @PutMapping("/")
    public Persona actualizar(@PathVariable Long id, @RequestBody Persona personaActualizada) {
        return personaService.actualizar(id, personaActualizada);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        personaService.delete(id);
    }

    @GetMapping("/encontrar-sospechoso/{cromosoma}")
    public String validCromosoma(@PathVariable String cromosoma) {
        return personaService.buscarSospechoso(cromosoma);
    }


}
